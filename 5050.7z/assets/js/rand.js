var LOOP_TIMES = 10; // How much times will iterate
var DELAY = 50; // default delay time
var DELAY_MULTIPLIER = 5; // delay multiplier for last item
var LAST_ITEM = 13; // last number to add more delay
var AUDIO_TICK = new Audio('assets/audio/pick.mp3');
var AUDIO_FINISH = new Audio('assets/audio/kids-hooray.mp3');

var INDEX_START = 0;
var NAMES = [];

//jamie: -2
//lenny: +1
//karen spiegel: +1


function start() {
    _hideElement("btn");
    _readFile();
    // loop();
}

function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * i);
        const temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
}

function animateNames(name) {
    var xMax = 1000;
    var yMax = 1000;

    name.keyframes = [{
        opacity: 0,
        transform: "translate3d(" + (Math.random() * xMax) + "px, " + (Math.random() * yMax) + "px, 0px)"
    }, {
        opacity: 1,
        transform: "translate3d(" + (Math.random() * xMax) + "px, " + (Math.random() * yMax) + "px, 0px)"
    }, {
        opacity: 0,
        transform: "translate3d(" + (Math.random() * xMax) + "px, " + (Math.random() * yMax) + "px, 0px)"
    }];

    name.animProps = {
        duration: 1000 + Math.random() * 3000,
        easing: "ease-out",
        iterations: 3
    };

    var animationPlayer = name.animate(name.keyframes, name.animProps);
    addFinishHandler(animationPlayer, name);
}

function addFinishHandler(anim, el) {
    anim.addEventListener('finish', function(e) {
        $(el).hide();
        // animateNames(el);
    }, false);
}

function _readFile() {

    $(document).ready(function () {
        $.ajax({
            type: "GET",
            url: "ExcelExportFixedPrice.csv",
            dataType: "text",
            success: function (data) {
                processData(data);
            }
        });

        function processData(data) {
            Papa.parse(data, {
                complete: function (results) {
                    for (var j = 1; j < results.data.length; j++) {
                        if (results.data[j][0]) {
                            if (parseInt(results.data[j][0]) === 372) {
                                NAMES.push('372 Jamie Lakin');
                                NAMES.push('xxx Lenny Teiber');
                                NAMES.push('xxx Karen Spiegel');
                            } else {
                                for (var k = 0; k < parseInt(results.data[j][17]); k++) {
                                    NAMES.push(results.data[j][0] + ' ' + results.data[j][2] + ' ' + results.data[j][3]);
                                }
                            }
                        }
                    }
                    shuffleArray(NAMES);
                    for (var m = 0; m < NAMES.length; m++) {
                        $("#mainContainer").append('<div class="name">' + NAMES[m] + '</div>');
                    }

                    var divnames = document.querySelectorAll(".name");

                    for (var i = 0; i < NAMES.length; i++) {
                        var name = divnames[i];
                        animateNames(name);
                    }
                }
            });
        }
    });
}

function loop() {
    var delay = DELAY;
    if (INDEX_START > LOOP_TIMES - LAST_ITEM) {
        delay = DELAY * DELAY_MULTIPLIER;
        DELAY_MULTIPLIER++;
    }
    // console.log('delay', delay);
    setTimeout(function () {
        var picked = NAMES[Math.floor(Math.random() * NAMES.length)]
        // console.log(picked);
        _setName(picked);
        AUDIO_TICK.play();
        INDEX_START++;
        if (INDEX_START < LOOP_TIMES) {
            loop();
        }

        if (INDEX_START === LOOP_TIMES) {
            // AUDIO_FINISH.play();
            _addClass(".primary-text", "animated infinite tada");
            window.doFireworks();
        }
    }, delay);
}

function _setName(name) {
    var targetDom = document.getElementById("target");
    targetDom.innerHTML = name;
}

function _hideElement(id) {
    var el = document.getElementById(id);
    el.style.display = 'none';
}

function _showElement(id) {
    var el = document.getElementById(id);
    el.style.display = 'inline-block';
}

function _addClass(targetEl, classes) {
    var el = document.querySelector(targetEl);
    el.className += " " + classes;
}