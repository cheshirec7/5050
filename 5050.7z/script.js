//

var Boid = Base.extend({
        initialize: function (position, maxSpeed, maxForce, bidNo) {
            var strength = Math.random() * 0.5;
            this.acceleration = new Point();
            this.vector = Point.random() * 2 - 1;
            this.position = position.clone();
            this.radius = gBallRadius;
            this.maxSpeed = maxSpeed + strength;
            this.maxForce = maxForce + strength;
            this.amount = strength * 10 + 10;
            this.bidNo = bidNo;
            this.createItems();
        },

        run: function (boids, isWinner) {
            if (gWinnerSelected && isWinner) {
                if (this.ball.children[0].radius < 125) {
                    this.radius++;
                    this.ball.children[0].radius = this.radius;
                }
                if (this.ball.children[1].fontSize < 100) {
                    this.ball.children[1].fontSize += 0.4;
                }
                this.ball.children[0].fillColor.hue = gWinnerNameText.fillColor.hue;
            } else if (!isWinner) {
                if (this.ball.children[0].radius > 50) {
                    this.radius -= 2;
                    this.ball.children[0].radius = this.radius;
                }
                if (this.ball.children[1].fontSize > 40) {
                    this.ball.children[1].fontSize -= 1.5;
                }
            }
            if (!gGroupTogether) {
                this.acceleration += (this.separate(boids) * 3)
            } else {
                this.align(boids);
            }
            this.borders();
            this.update();
        },

        createItems: function () {

            var color = {
                    hue: 0,
                    saturation: Math.random() + 0.5,
                    brightness: Math.random() + 0.25
                },
                sphere = new Shape.Circle({
                    radius: this.radius,
                    fillColor: color
                }), textItem = new PointText({
                    point: [0, 15],
                    fillColor: 'white',
                    content: this.bidNo,
                    fontSize: 200,
                    justification: 'center'
                });

            this.ball = new Group(sphere, textItem);

            this.path = new Path();
            for (var i = 0; i < this.amount; i++)
                this.path.add(new Point());
        },

        borders: function () {
            var vector = new Point(),
                position = this.position,
                radius = this.radius,
                size = view.size;
            if (position.x < -radius) vector.x = size.width + radius;
            if (position.y < -radius) vector.y = size.height + radius;
            if (position.x > size.width + radius) vector.x = -size.width - radius;
            if (position.y > size.height + radius) vector.y = -size.height - radius;
            if (!vector.isZero()) {
                this.position += vector;
                var segments = this.path.segments;
                for (var i = 0; i < this.amount; i++) {
                    segments[i].point += vector;
                }
            }
        },

        update: function () {
            this.vector += this.acceleration;
            // Limit speed (vector#limit?)
            this.vector.length = Math.min(this.maxSpeed, this.vector.length);
            this.position += this.vector;
            // Reset acceleration to 0 each cycle
            this.acceleration = new Point();
            this.ball.position = this.position;
        },

        // seek: function (target) {
        //     this.acceleration += this.steer(target, false);
        // },

        arrive: function (target) {
            this.acceleration += this.steer(target, true);
        },

        steer: function (target, slowdown) {
            var steer,
                desired = target - this.position,
                distance = desired.length;
            // Two options for desired vector magnitude
            // (1 -- based on distance, 2 -- maxSpeed)
            if (slowdown && distance < 100) {
                // This damping is somewhat arbitrary:
                desired.length = this.maxSpeed * (distance / 100);
            } else {
                desired.length = this.maxSpeed;
            }
            steer = desired - this.vector;
            if (!gGroupTogether) /////////////////////////////////////// makes balls go directly to heart
                steer.length = Math.min(this.maxForce, steer.length);
            return steer;
        },

        getSteer: function (count, steer) {
            // Average -- divide by how many
            if (count > 0)
                steer /= count;
            if (!steer.isZero()) {
                // Implement Reynolds: Steering = Desired - Velocity
                steer.length = this.maxSpeed;
                steer -= this.vector;
                steer.length = Math.min(steer.length, this.maxForce);
            }
            return steer;
        },

        separate: function (boids) {
            var steer = new Point(),
                count = 0;
            // check if it's too close
            for (var i = 0, l = boids.length; i < l; i++) {
                var other = boids[i],
                    vector = this.position - other.position,
                    distance = vector.length;
                if (distance > 0 && distance < gDesiredSeparation) {
                    // Calculate vector pointing away from neighbor
                    steer += vector.normalize(1 / distance);
                    count++;
                }
            }
            return this.getSteer(count, steer);
        },

        // For every nearby boid in the system, calculate the average velocity
        align: function (boids) {
            var steer = new Point(),
                count = 0;
            for (var i = 0, l = boids.length; i < l; i++) {
                var other = boids[i],
                    distance = this.position.getDistance(other.position);
                if (distance > 0 && distance < gNeighborDistAlign) {
                    steer += other.vector;
                    count++;
                }
            }
            return this.getSteer(count, steer);
        },
    }),

    Firework = Base.extend({
        initialize: function (sx, sy, tx, ty) {
            // actual coordinates
            this.x = sx;
            this.y = sy;
            // starting coordinates
            this.sx = sx;
            this.sy = sy;
            // target coordinates
            this.tx = tx;
            this.ty = ty;
            // distance from starting point to target
            this.distanceToTarget = calculateDistance(sx, sy, tx, ty);
            this.distanceTraveled = 0;
            // track the past coordinates of each firework to create a trail effect, increase the coordinate count to create more prominent trails
            this.coordinates = [];
            this.coordinateCount = 3;
            // populate initial coordinate collection with the current coordinates
            while (this.coordinateCount--) {
                this.coordinates.push([this.x, this.y]);
            }
            this.angle = Math.atan2(ty - sy, tx - sx);
            this.speed = 2;
            this.acceleration = 1.05;
            // circle target indicator radius
            this.targetRadius = 1;
            // this.test = 0;

            var color = {
                hue: this.hue,
                saturation: 255,
                brightness: random(50, 70)
            };

            this.sphere = new Shape.Circle({
                radius: 3,
                fillColor: color
            });

            this.sphere.position.x = this.x;
            this.sphere.position.y = this.y;
        },
        update: function (index) {
            this.coordinates.pop();
            this.coordinates.unshift([this.x, this.y]);

            // cycle the circle target indicator radius
            if (this.targetRadius < 8) {
                this.targetRadius += 0.3;
            } else {
                this.targetRadius = 1;
            }

            // speed up the firework
            this.speed *= this.acceleration;

            // get the current velocities based on angle and speed
            var vx = Math.cos(this.angle) * this.speed,
                vy = Math.sin(this.angle) * this.speed;
            // how far will the firework have traveled with velocities applied?
            this.distanceTraveled = calculateDistance(this.sx, this.sy, this.x + vx, this.y + vy);

            // if the distance traveled, including velocities, is greater than the initial distance to the target, then the target has been reached
            if (this.distanceTraveled >= this.distanceToTarget) {
                createParticles(this.tx, this.ty);
                // remove the firework, use the index passed into the update function to determine which to remove
                fireworks.splice(index, 1);
            } else {
                // target not reached, keep traveling
                this.sphere.position.x += vx;
                this.sphere.position.y += vy;
            }
        },
        draw: function () {
            // ctx.beginPath();
            // // move to the last tracked coordinate in the set, then draw a line to the current x and y
            // ctx.moveTo(this.coordinates[this.coordinates.length - 1][0], this.coordinates[this.coordinates.length - 1][1]);
            // ctx.lineTo(this.x, this.y);
            // ctx.strokeStyle = 'hsl(' + hue + ', 100%, ' + this.brightness + '%)';
            // ctx.stroke();
            //
            // ctx.beginPath();
            // // draw the target for this firework with a pulsing circle
            // ctx.arc(this.tx, this.ty, this.targetRadius, 0, Math.PI * 2);
            // ctx.stroke();
            // console.log('fw draw');
            this.sphere.position.x = this.tx;
            this.sphere.position.y = this.ty;
        }
    }),

    Particle = Base.extend({
        initialize: function (x, y) {
            this.x = x;
            this.y = y;
            // track the past coordinates of each particle to create a trail effect, increase the coordinate count to create more prominent trails
            this.coordinates = [];
            this.coordinateCount = 5;
            while (this.coordinateCount--) {
                this.coordinates.push([this.x, this.y]);
            }
            // set a random angle in all possible directions, in radians
            this.angle = random(0, Math.PI * 2);
            this.speed = random(1, 10);
            // friction will slow the particle down
            this.friction = 0.95;
            // gravity will be applied and pull the particle down
            this.gravity = 1;
            this.alpha = 1;
            // set how fast the particle fades out
            this.decay = random(0.015, 0.03);

            var color = {
                hue: random(fw_hue - 50, fw_hue + 50),
                saturation: 255,
                brightness: random(50, 80)
            };

            this.myparticle = new Shape.Circle({
                radius: 2,
                fillColor: color,
            });

            this.myparticle.position.x = this.x;
            this.myparticle.position.y = this.y;
        },
        update: function (index) {
            // remove last item in coordinates array
            this.coordinates.pop();
            // add current coordinates to the start of the array
            this.coordinates.unshift([this.x, this.y]);
            // slow down the particle
            this.speed *= this.friction;
            // apply velocity
            this.x += Math.cos(this.angle) * this.speed;
            this.y += Math.sin(this.angle) * this.speed + this.gravity;
            // fade out the particle
            this.alpha -= this.decay;

            // remove the particle once the alpha is low enough, based on the passed in index
            if (this.alpha <= this.decay) {
                particles.splice(index, 1);
            }
        },
        draw: function () {
            // console.log('pctl draw');
            // ctx.beginPath();
            // // move to the last tracked coordinates in the set, then draw a line to the current x and y
            // ctx.moveTo(this.coordinates[this.coordinates.length - 1][0], this.coordinates[this.coordinates.length - 1][1]);
            // ctx.lineTo(this.x, this.y);
            // ctx.strokeStyle = 'hsla(' + this.hue + ', 100%, ' + this.brightness + '%, ' + this.alpha + ')';
            // ctx.stroke();

            this.myparticle.position.x = this.x;
            this.myparticle.position.y = this.y;
            this.myparticle.fillColor.alpha = this.alpha;
        }
    }),

    gCreateBoidTimer = null,
    gRasterLogo = new Raster({
        source: 'assets/img/logo.png',
    }),

    g5050Text = new PointText(),
    // gButterfly= new Raster({
    //     source: 'assets/img/butt.gif',
    // }),
    //
    // gButterflyDest = Point.random() * view.size,

    gBIDDERNAMES = [],
    gBIDDERNUMS = [],
    boids = [],
    gaIdx = 0,
    gWinnerIdx = -1,
    gWinnerFillColor,
    gWinnerSelected = false,
    gWinnerNameText,
    g5050WinnerTextTopLeft,
    g5050WinnerTextTopRight,
    g5050WinnerTextBotLeft,
    g5050WinnerTextBotRight,
    gGroupTogether = false,
    gBallRadius = 250,
    gNeighborDistAlign = 25, //25
    gDesiredSeparation = 100, //60
    gCreateComplete = false,
    gPhaseNo = 0,
    gClickNo = 0,
    gCenterPoint = new Point(view.size / 2),

    gKidSound = new Howl({
        src: ['assets/audio/kids-hooray.mp3']
    }),
    gDrumSound = new Howl({
        src: ['assets/audio/drum_roll.mp3'],
        loop: true
        // onend: function () {
        //     gCrashSound.play();
        // }
    }),
    gCrashSound = new Howl({
        src: ['assets/audio/crash.mp3'],
        // onend: function () {
        //     gKidSound.play();
        // }
    }),
    gLotterySound = new Howl({
        src: ['assets/audio/lottery.mp3'],
        loop: true
    }),
    gChimesSound = new Howl({
        src: ['assets/audio/chimes1.mp3'],
        preload: true,
        onend: function () {
            gDrumSound.play();
        }
    }),
    gWinnerBellSound = new Howl({
        src: ['assets/audio/winner-bell.mp3'],
        preload: true,
        onend: function () {
            // gDrumSound.play();
            gKidSound.play();
        }
    }),
    // gJeopardySound = new Howl({
    //     src: ['assets/audio/jeopardy.mp3'],
    //     loop: true
    // }),

// var sound = new Howl({
//     src: ['sound.webm', 'sound.mp3', 'sound.wav'],
//     autoplay: true,
//     loop: true,
//     volume: 0.5,
//     onend: function() {
//         console.log('Finished!');
//     }
// });


    gHeartPath = new Path('M514.69629,624.70313c-7.10205,-27.02441 -17.2373,-52.39453 -30.40576,-76.10059c-13.17383,' +
        '-23.70703 -38.65137,-60.52246 -76.44434,-110.45801c-27.71631,-36.64355 -44.78174,-59.89355 -51.19189,-69.74414c-10.5376,' +
        '-16.02979 -18.15527,-30.74951 -22.84717,-44.14893c-4.69727,-13.39893 -7.04297,-26.97021 -7.04297,-40.71289c0,' +
        '-25.42432 8.47119,-46.72559 25.42383,-63.90381c16.94775,-17.17871 37.90527,-25.76758 62.87354,-25.76758c25.19287,' +
        '0 47.06885,8.93262 65.62158,26.79834c13.96826,13.28662 25.30615,33.10059 34.01318,59.4375c7.55859,-25.88037 18.20898,' +
        '-45.57666 31.95215,-59.09424c19.00879,-18.32178 40.99707,-27.48535 65.96484,-27.48535c24.7373,0 45.69531,' +
        '8.53564 62.87305,25.5957c17.17871,17.06592 25.76855,37.39551 25.76855,60.98389c0,20.61377 -5.04102,42.08691 -15.11719,' +
        '64.41895c-10.08203,22.33203 -29.54687,51.59521 -58.40723,87.78271c-37.56738,47.41211 -64.93457,86.35352 -82.11328,' +
        '116.8125c-13.51758,24.0498 -23.82422,49.24902 -30.9209,75.58594z'),

    fireworks = [],
    particles = [],
    fw_hue = 120,
    timerTotal = 80,
    timerTick = 0,
    doFireworks = false,
    soundTimer;


gRasterLogo.scale(0.2);
g5050Text.fontSize = 100;
g5050Text.fillColor = '#e97724';
g5050Text.content = '50/50 Raffle';
gHeartPath.fitBounds(view.bounds);
gHeartPath.scale(0.8);
loadData();

function arrShuffle(arr1, arr2) {
    var currentIndex = arr1.length, temporaryValue, randomIndex;
    while (0 !== currentIndex) {
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex -= 1;
        temporaryValue = arr1[currentIndex];
        arr1[currentIndex] = arr1[randomIndex];
        arr1[randomIndex] = temporaryValue;

        temporaryValue = arr2[currentIndex];
        arr2[currentIndex] = arr2[randomIndex];
        arr2[randomIndex] = temporaryValue;
    }
    return arr1;
}

// function getRandomColor() {
//     return new Color({
//         hue: randomRange(0, 100),
//         saturation: 0.75,
//         lightness: 0.5
//     })
// }

function calculateDistance(p1x, p1y, p2x, p2y) {
    var xDistance = p1x - p2x,
        yDistance = p1y - p2y;
    return Math.sqrt(Math.pow(xDistance, 2) + Math.pow(yDistance, 2));
}

// get a random number within a range
function random(min, max) {
    return Math.random() * (max - min) + min;
}

function randomRange(min, max, floor) {
    var v = min + Math.random() * (max - min);
    floor = floor || false;
    return floor ? (v | 0) : v;
}

function randomIndex(arr) {
    return randomRange(0, arr.length, true);
}

function createBoidTimer() {
    boids.push(new Boid(gCenterPoint, 10, 0.05, gBIDDERNUMS[gaIdx]));
    gaIdx++;

    if (gaIdx === gBIDDERNUMS.length) {
        window.clearInterval(gCreateBoidTimer);
        // gLotterySound.stop();
        gDrumSound.stop();
        gCrashSound.play();
        gCreateComplete = true;
    }
}

function loadData() {
    $.ajax({
        type: "GET",
        url: "ExcelExportFixedPrice.csv",
        dataType: "text",
        success: function (data) {
            processData(data);
        }
    });
}

function processData(data) {
    var jamieFound = false;
    Papa.parse(data, {
        complete: function (results) {
            for (var j = 1; j < results.data.length; j++) {
                var bidderNo = parseInt(results.data[j][0]),
                    pkgNum = parseInt(results.data[j][15]),
                    numBought = parseInt(results.data[j][17]);

                if (pkgNum === 50) {
                    if (bidderNo === 372 && numBought === 3 && !jamieFound) {
                        gBIDDERNAMES.push('JAMIE LAKIN');
                        gBIDDERNAMES.push('LENNY TEIBER');
                        gBIDDERNAMES.push('KAREN SPEIGEL');
                        gBIDDERNUMS.push(372);
                        gBIDDERNUMS.push(420);
                        gBIDDERNUMS.push(700);
                        jamieFound = true;
                    } else {
                        for (var k = 0; k < numBought; k++) {
                            gBIDDERNAMES.push(results.data[j][2].toUpperCase() +
                                ' ' + results.data[j][3].toUpperCase());
                            gBIDDERNUMS.push(bidderNo);
                        }
                    }
                }
            }
            arrShuffle(gBIDDERNAMES, gBIDDERNUMS);
        }
    });
}

function selectWinner() {
    // console.log(gWinnerFillColor);
    if (gWinnerIdx >= 0) {
        boids[gWinnerIdx].ball.children[0].fillColor = gWinnerFillColor;
        boids[gWinnerIdx].ball.children[0].radius = 100;
        boids[gWinnerIdx].ball.children[1].fontSize = 40;
    }
    gWinnerIdx = randomIndex(boids);
    gWinnerFillColor = boids[gWinnerIdx].ball.children[0].fillColor;

    boids[gWinnerIdx].ball.children[0].fillColor = 'green';
    boids[gWinnerIdx].ball.children[0].radius = 125;
    boids[gWinnerIdx].ball.children[1].fontSize = 100;
}

function onFrame(event) {
    // fireworkLoop();
    // return;

    var i, point;

    switch (gPhaseNo) {
        case 0:
            g5050Text.fillColor.hue += 1;
            break;
        case 1:
            gRasterLogo.position.x += 20;
            g5050Text.position.x -= 20;
            g5050Text.fillColor.alpha -= 0.01;
            if (view.size.width - (gRasterLogo.position.x - gRasterLogo.size.width * gRasterLogo.scaling.x / 2) <= 0) {
                gCreateBoidTimer = setInterval(createBoidTimer, 50);
                gPhaseNo++;
            }
            break;
    }

    for (i = 0, l = boids.length; i < l; i++) {
        if (gGroupTogether) {
            var length;

            if (i === gWinnerIdx) {
                point = gCenterPoint;
                point.y = view.size.height / 2 - 40;
            } else {
                length = ((i + event.count / 30) % l) / l * gHeartPath.length;
                point = gHeartPath.getPointAt(length);
            }

            if (point) {
                boids[i].arrive(point);
            }
        }
        boids[i].run(boids, i === gWinnerIdx);
    }

    if (gWinnerNameText) {
        point = gCenterPoint;
        point.y = view.size.height / 2 + 70;
        gWinnerNameText.position += ((point - gWinnerNameText.position) / 30);
        gWinnerNameText.fillColor.hue++;
    }

    if (!gWinnerSelected && gCreateComplete && event.count % 30 === 0) {
        selectWinner();
    }
}

function onResize(event) {
    switch (gPhaseNo) {
        case 0:
            gRasterLogo.position = new Point(view.size / 2);
            gRasterLogo.position.y -= 150;
            g5050Text.position = new Point(view.size / 2);
            g5050Text.position.y += 200;
            break;
    }

    gCenterPoint = new Point(view.size / 2);
    gHeartPath.fitBounds(view.bounds);
    gHeartPath.scale(0.8);
}

// function lotteryFunc() {
// if (gLotterySound) {
// gLotterySound.play();
// clearTimeout(soundTimer);
// }
// }

function kidFunc() {
    gKidSound.play();
}

// no clicks/init screen: logo/5050/ball
// click1: play bell, start ball shuffling sound
// click2: start drum roll
// click3: stop drum, play crash, play kids
function onMouseDown(event) {

    // doFireworks = true;
    // return;

    switch (gClickNo) {
        case 0:
            gChimesSound.play();
            gClickNo++;
            gPhaseNo++;
            break;
        case 1:
            if (gCreateComplete) {

                gWinnerSelected = true;
                gWinnerNameText = new PointText({
                    point: [view.size.width / 2, view.size.height],
                    fillColor: 'blue',
                    // content: gBIDDERNAMES[winIndex],
                    content: gBIDDERNAMES[gWinnerIdx],
                    fontWeight: 'bold',
                    strokeColor: 'white',
                    strokeWidth: 3,
                    justification: 'center'
                });
                //

                // gWinnerNameText.content = 'Jamie & Bill Lakin Kelley / Kelley';
                gWinnerNameText.fontSize = 100;
                if (gWinnerNameText.content.length > 20) {
                    gWinnerNameText.fontSize = 90;
                }

                g5050WinnerTextTopLeft = new PointText({
                    position: new Point(50, 50),
                    fillColor: '#a04d12',
                    content: '50/50 WINNER!',
                    strokeColor: 'orange',
                    strokeWidth: 1,
                    justification: 'left',
                    fontSize: 30
                });

                g5050WinnerTextBotLeft = new PointText({
                    position: new Point(50, view.size.height - 50),
                    fillColor: '#a04d12',
                    content: '50/50 WINNER!',
                    strokeColor: 'orange',
                    strokeWidth: 1,
                    justification: 'left',
                    fontSize: 30
                });

                g5050WinnerTextTopRight = new PointText({
                    position: new Point(view.size.width - 50, 50),
                    fillColor: '#a04d12',
                    content: '50/50 WINNER!',
                    strokeColor: 'orange',
                    strokeWidth: 1,
                    justification: 'right',
                    fontSize: 30
                });

                g5050WinnerTextBotRight = new PointText({
                    position: new Point(view.size.width - 50, view.size.height - 50),
                    fillColor: '#a04d12',
                    content: '50/50 WINNER!',
                    strokeColor: 'orange',
                    strokeWidth: 1,
                    justification: 'right',
                    fontSize: 30
                });

                doFireworks = true;

                // gDrumSound.stop();
                // gCrashSound.play();
                gWinnerBellSound.play();
                // setTimeout(kidFunc, 500);
                gClickNo++;
            }
            break;
    }

    if (gCreateComplete) {
        gGroupTogether = !gGroupTogether;
        if (gGroupTogether) {
            boids[boids.length - 1].ball.children[1].fillColor = boids[boids.length - 1].ball.children[0].fillColor;
        } else {
            boids[boids.length - 1].ball.children[1].fillColor = 'white';
        }
    }
}


// ********** FIREWORKS ***************

// create particle group/explosion
function createParticles(x, y) {
    // increase the particle count for a bigger explosion, beware of the canvas performance hit with the increased particles though
    var particleCount = 30;
    while (particleCount--) {
        particles.push(new Particle(x, y));
    }
}

// main demo loop
function fireworkLoop() {
    var i;
    // increase the hue to get different colored fireworks over time
    //hue += 0.5;

    // create random color
    fw_hue = random(0, 360);

    // normally, clearRect() would be used to clear the canvas
    // we want to create a trailing effect though
    // setting the composite operation to destination-out will allow us to clear the canvas at a specific opacity, rather than wiping it entirely
    // ctx.globalCompositeOperation = 'destination-out';
    // decrease the alpha property to create more prominent trails
    // ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
    // ctx.fillRect( 0, 0, cw, ch );
    // change the composite operation back to our main mode
    // lighter creates bright highlight points as the fireworks and particles overlap each other
    // ctx.globalCompositeOperation = 'lighter';


    for (i = fireworks.length - 1; i >= 0; i--) {
        // console.log('i=' + ' ' + i);
        fireworks[i].draw();
        fireworks[i].update(i);
    }

    for (i = particles.length - 1; i >= 0; i--) {
        particles[i].draw();
        particles[i].update(i);
    }

    // launch fireworks automatically to random coordinates
    if (timerTick >= timerTotal) {
        // start the firework at the bottom middle of the screen, then set the random target coordinates,
        // the random y coordinates will be set within the range of the top half of the screen
        fireworks.push(new Firework(view.size.width / 2, view.size.height, random(0, view.size.width), random(0, view.size.height / 2)));
        // console.log('pushed');
        timerTick = 0;
    } else {
        timerTick++;
    }
}


////////////
// CLASSES
////////////
// function Hex(position, targetRadius, color) {
//     var subs = 3;
//
//     this.radius = targetRadius;
//     this.sides = randomIndex([4, 6, 8, 10, 12]);
//     this.targetHex = new Path.RegularPolygon(position, this.sides, targetRadius);
//     this.paths = [];
//
//     for (var i = 0; i < subs; i++) {
//         var h = new Path.RegularPolygon(position, this.sides, 0);
//
//         if (i === 0) {
//             h.strokeColor = color;
//         } else {
//             h.strokeColor = new Color({
//                 hue: color.hue,
//                 saturation: color.saturation,
//                 lightness: randomRange(0.4, 0.6),
//                 alpha: 1
//             });
//         }
//
//         h.strokeWidth = 24;
//         h.shadowBlur = 64;
//         h.shadowColor = h.strokeColor;
//
//         this.paths.push(h);
//     }
//
//     this.color = this.paths[subs - 1].strokeColor;
//
//     this.speed = 125;
// }

// Hex.prototype = {
//     animate: function () {
//         var tl = new TimelineMax({
//             onComplete: function () {
//                 this.paths.forEach(function (p) {
//                     p.remove();
//                 });
//             },
//             onCompleteScope: this
//         });
//
//         var duration = this.radius / this.speed,
//             offset = 0,
//             ease = Cubic.easeOut;
//
//         this.paths.forEach(function (h) {
//             var from, to;
//
//             for (var i = 0; i < h.segments.length; i++) {
//                 from = h.segments[i].point;
//                 to = this.targetHex.segments[i].point;
//
//                 tl.to(from, duration, {x: to.x, y: to.y, ease: ease}, offset);
//                 tl.to(h, duration, {strokeWidth: 0, ease: ease}, offset);
//             }
//
//             offset += 0.2;
//
//         }, this);
//
//         return tl;
//     }
// };

// function Line(start, angle, length, color) {
//     this.start = start;
//     this.end = new Point();
//
//     this.end.setAngle(angle);
//     this.end.setLength(length);
//     this.end += this.start;
//
//     this.path = new Path();
//     this.path.add(this.start, this.end);
//     this.color = this.path.strokeColor = color;
//     this.path.visible = false;
//     this.path.strokeWidth = 2;
//     this.path.strokeCap = 'round';
//     this.path.shadowBlur = 32;
//     this.path.shadowColor = this.color;
//
//     this.speed = 250;
// }

// Line.prototype = {
//     animate: function () {
//         var tl = new TimelineMax({
//             onStart: function () {
//                 this.path.visible = true;
//             },
//             onStartScope: this,
//             onComplete: function () {
//                 this.path.remove();
//             },
//             onCompleteScope: this
//         });
//
//         var start = this.path.segments[0].point,
//             end = this.path.segments[1].point;
//
//         var duration = this.path.length / this.speed,
//             ease = Cubic;
//
//         tl.from(end, duration, {x: start.x, y: start.y, ease: ease.easeInOut});
//         tl.to(start, duration * 0.75, {x: end.x, y: end.y, ease: ease.easeOut}, '-=0.5');
//
//         return tl;
//     }
// };

// function createFirework() {
//     var tl = new TimelineMax();
//
//     var startPoint = new Point(view.size.width * Math.random(), view.size.height),
//         angle = 270,
//         length = view.size.height * 0.5,
//         size = randomRange(64, 396),
//         color = getRandomColor();
//
//     var trail = new Line(startPoint, angle, length, color),
//         hex = new Hex(trail.end, size, color);
//
//     tl.add(trail.animate());
//     tl.add('trailDone');
//
//     tl.add(hex.animate(), 'trailDone');
//
//     for (var i = 0; i < hex.sides; i++) {
//
//         var point = hex.targetHex.segments[i].point,
//             localPoint = point - hex.targetHex.position;
//
//         var spark = new Line(trail.end, localPoint.angle, size * 2, color);
//
//         tl.add(spark.animate(), 'trailDone');
//     }
//
//     return tl;
// }


